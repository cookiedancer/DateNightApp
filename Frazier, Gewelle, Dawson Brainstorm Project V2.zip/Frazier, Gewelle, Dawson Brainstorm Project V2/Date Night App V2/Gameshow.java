import greenfoot.*;

/**
 * Gameshow World
 * 
 * @Paul Frazier, Terrence Dawson, Gewelle Ross 
 * @V1.2
 */
public class Gameshow extends World
{//Start Class
    GreenfootSound myMusic = new GreenfootSound("Showmusic.mp3");
    /**
     * Constructor for objects of class Gameshow.
     * 
     */
    public Gameshow()
    
    {//Start Method
        super(1000, 600, 1); 
        Gamescreen Board = new Gamescreen();
        addObject(Board, 480,320);
    }//End Method
    
    public void act()
    //game music method
    {
        myMusic.play();
    }
 
}//End Class
