import greenfoot.*;

/**
 * Gamescreen selects actions
 * 
 * @aurthor Paul Frazier, Terrence Dawson, Gewelle Ross
 * @version 1.3
 */
public class Gamescreen extends Actor
{//Start Class
    
    /**
     * Act - do whatever the Gamescreen wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {//Start method
        // Add your action code here.
    }//End method

}//End Class