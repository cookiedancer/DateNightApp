import greenfoot.*;

/**
 * Write a description of class Golf here.
 * 
 * @author Paul Frazier, Terrence Dawson, Gewelle Ross 
 * @version 1.3
 */
public class Golf extends Games
{//Start class
    /**
     * Act - do whatever the Golf wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {//Start method
        if(Greenfoot.isKeyDown("Backspace"))
        getWorld().removeObject(this);
    }//End method    
}//End class
