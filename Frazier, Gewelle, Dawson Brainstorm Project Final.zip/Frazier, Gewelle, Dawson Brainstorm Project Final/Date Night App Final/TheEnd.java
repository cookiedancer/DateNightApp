import greenfoot.*;

/**
 * TheEnd class is the ending screen of the game.
 * 
 * @author Paul Frazier, Terrence Dawson, Gewelle Ross
 * @version 1.3
 */
public class TheEnd extends StartScreen
{

    /**
     * Constructor for objects of class TheEnd.
     * 
     */
    public TheEnd()
    {
       //type action code here  
    }
}
