import greenfoot.*;

/**
 * Write a description of class Instructions here.
 * 
 * @aurthor Paul Frazier, Terrence Dawson, Gewelle Ross
 * @version 1.3
 */
public class Instructions extends Gamescreen
{//Start class
    /**
     * Act - do whatever the Instructions wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {//Start method
        // Add your action code here.
    }//End method    
}//End class
