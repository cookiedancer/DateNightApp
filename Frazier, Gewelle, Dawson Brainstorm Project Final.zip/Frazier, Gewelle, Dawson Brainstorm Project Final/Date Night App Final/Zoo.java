import greenfoot.*;

/**
 * Write a description of class Zoo here.
 * 
 * @author Paul Frazier, Terrence Dawson, Gewelle Ross 
 * @version 1.3
 */
public class Zoo extends Location
{//Start class
    /**
     * Act - do whatever the Zoo wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {//Start method
        if(Greenfoot.isKeyDown("Backspace"))
        getWorld().removeObject(this);
    }//End method    
}//End class
