import greenfoot.*;

/**
 * Write a description of class Movie here.
 * 
 * @author Paul Frazier, Terrence Dawson, Gewelle Ross
 * @version 1.3
 */
public class Movie extends Gamescreen
{//Start class
    /**
     * Act - do whatever the Movie wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {//Start method
        // Add your action code here.
    }//End method    
}//End class
