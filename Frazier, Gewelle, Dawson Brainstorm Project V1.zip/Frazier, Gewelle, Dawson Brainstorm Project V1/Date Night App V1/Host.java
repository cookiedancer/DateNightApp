import greenfoot.*;

/**
 * Host announces selections
 * 
 * @author (your name) 
 * @V1.0
 */
public class Host extends Actor
{
    /**
     * Act - do whatever the Host wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }  
    
    
    
    public void setLocation()
    {
       setLocation(600,300); 
    }
}
